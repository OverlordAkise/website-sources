--Luctus NLR
--Made by OverlordAkise

LUCTUS_NLR_SIZE = 20
LUCTUS_NLR_MATERIAL = "models/wireframe"
LUCTUS_NLR_TEXT = "Please leave NLR"

print("[luctus_nlr] SH loaded")
