--Luctus Safezones
--Made by OverlordAkise

LUCTUS_SAFEZONE_TEXT = "Safezone"

print("[luctus_safezones] SH loaded!")
