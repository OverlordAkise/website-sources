--Luctus Taser
--Made by OverlordAkise

LTAZER_MAXRANGE = 450;
LTAZER_STUNTIME = 3;
LTAZER_FREEZETIME = 4;
