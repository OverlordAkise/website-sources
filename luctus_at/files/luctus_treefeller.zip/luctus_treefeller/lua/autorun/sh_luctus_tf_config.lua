--Luctus Treefeller
--Made by OverlordAkise

-- $SELLPRICE$ will be replaced automatically with the sellprice
LUCTUS_TREE_RESPAWNTIME = 120
LUCTUS_TREE_LOG_TEXT = "[E] Sell for $SELLPRICE$ €" 
LUCTUS_TREE_LOG_SOLD_TEXT = "You got $SELLPRICE$ € for that log."
LUCTUS_TREE_LOG_COUNT = 6 --How many logs spawn
LUCTUS_TREE_LOG_SELLPRICE = 100

print("[luctus_treefeller] SH config loaded!")
