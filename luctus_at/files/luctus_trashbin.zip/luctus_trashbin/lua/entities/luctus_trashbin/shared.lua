AddCSLuaFile()
ENT.Type = 'anim'
ENT.Base = "base_gmodentity"

ENT.Name = "Trashbin"
ENT.PrintName = "Trashbin"
ENT.Author = "OverlordAkise"
ENT.Category = "Luctus"
ENT.Purpose = "Throw entities away with it!"
ENT.Instructions = "N/A"
ENT.Model = "models/props_trainstation/trashcan_indoor001b.mdl"

ENT.Freeze = false
ENT.Spawnable = true
ENT.AdminSpawnable = false

ENT.HP = 50
