AddCSLuaFile()
ENT.Type = 'anim'
ENT.Base = "base_gmodentity"

ENT.Name = "Police Confiscation Box"
ENT.PrintName = "Police Confiscation Box"
ENT.Author = "OverlordAkise"
ENT.Category = "Luctus"
ENT.Purpose = "Put Entities in it and get money!"
ENT.Instructions = "N/A"
ENT.Model = "models/props/cs_militia/footlocker01_open.mdl"

ENT.Freeze = false
ENT.Spawnable = true
ENT.AdminSpawnable = false

ENT.HP = 50
